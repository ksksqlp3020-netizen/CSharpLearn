new MyGame().Run();
